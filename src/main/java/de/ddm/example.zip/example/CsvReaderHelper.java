package de.ddm.example;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.CSVParserBuilder;
import com.opencsv.exceptions.CsvValidationException;

import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CsvReaderHelper {

    public static List<List<String>> readCSVData(String csvFilePath) throws IOException {
        List<List<String>> data = new ArrayList<>();

        try (CSVReader reader = new CSVReaderBuilder(new FileReader(csvFilePath))
                .withCSVParser(new CSVParserBuilder().withSeparator(';').build()) // Use semicolon as the delimiter
                .build()) {
            String[] nextLine;
            boolean firstRow = true;

            // Read the data row by row
            while ((nextLine = reader.readNext()) != null) {
                if (firstRow) {
                    firstRow = false; // Skip the first row (header)
                    continue;
                }

                // Convert the row into a List and add it to the data
                List<String> row = Arrays.asList(nextLine);
                data.add(row);
            }
        } catch (CsvValidationException e) {
            throw new RuntimeException("Error validating CSV file", e);
        }

        return data;
    }
}
