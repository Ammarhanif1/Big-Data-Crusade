package de.ddm.example;

public class FinalizeMessage {
    // This class will be used to signal the end of the time measurement.
}
