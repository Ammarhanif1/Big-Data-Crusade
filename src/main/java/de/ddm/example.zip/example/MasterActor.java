package de.ddm.example;
import akka.actor.AbstractActor;
import akka.actor.ActorRef;
import akka.actor.Props;

public class MasterActor extends AbstractActor {
    private final ActorRef minerActor;

    public MasterActor(ActorRef minerActor) {
        this.minerActor = minerActor;
    }

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(CheckData.class, data -> {
                    // Send StartMessage to start timing
                    getContext().getSystem().actorSelection("/user/ResultCollector").tell(new StartMessage(), getSelf());

                    // Distribute the data to workers (shard the data)
                    ActorRef worker = getContext().actorOf(Props.create(DependencyWorker.class));
                    worker.tell(new CheckData(data.allTables), getSelf());
                })
                .match(WorkerResult.class, result -> {
                    // Send results to DependencyMiner for final aggregation
                    minerActor.tell(result, getSelf());
                })
                .build();
    }
}
