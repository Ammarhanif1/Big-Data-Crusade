package de.ddm.example;
import akka.actor.AbstractActor;

import java.util.List;
import java.util.Set;
import java.util.HashSet;

public class DependencyWorker extends AbstractActor {

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(CheckData.class, data -> {
                    boolean isValid = checkInclusionDependency(data.allTables);
                    getSender().tell(new WorkerResult(isValid, "All columns comparison complete."), getSelf());
                })
                .build();
    }

    // Method to check if all values in one table's columns are present in another table's columns
    private boolean checkInclusionDependency(List<List<List<String>>> allTables) {
        boolean isValid = false;

        // Iterate over all pairs of tables
        for (int i = 0; i < allTables.size(); i++) {
            List<List<String>> tableA = allTables.get(i);

            // Compare each column in tableA with other columns in the same tableA (same table)
            for (int columnA = 0; columnA < tableA.get(0).size(); columnA++) {
                String columnAName = "Table " + (i + 1) + " Column " + (columnA + 1);
                Set<String> setA = new HashSet<>();

                // Add all values of columnA to setA
                for (List<String> row : tableA) {
                    setA.add(row.get(columnA).trim().toLowerCase());  // Normalize case and trim
                }

                // Now compare columnA with every other column in the same tableA
                for (int columnB = 0; columnB < tableA.get(0).size(); columnB++) {
                    if (columnA == columnB) continue;  // Skip comparing the column to itself

                    String columnBName = "Table " + (i + 1) + " Column " + (columnB + 1);

                    // Check if all values in columnB are in setA
                    for (List<String> row : tableA) {
                        String item = row.get(columnB).trim().toLowerCase();  // Normalize case and trim
                        if (!setA.contains(item)) {
                            System.out.println("No Inclusion Dependency between " + columnAName + " and " + columnBName + ": " + item);
//                            isValid = false;  // If any item in columnB is not in setA, mark as invalid
                        } else {
                            System.out.println("Inclusion Dependency between " + columnAName + " and " + columnBName + ": " + item);
                            isValid = true;
                        }
                    }
                }
            }

            // Compare columns in tableA with columns in all other tables (tableB)
            for (int j = i + 1; j < allTables.size(); j++) {
                List<List<String>> tableB = allTables.get(j);

                // Iterate over columns of tableA and compare with all columns of tableB
                for (int columnA = 0; columnA < tableA.get(0).size(); columnA++) {
                    String columnAName = "Table " + (i + 1) + " Column " + (columnA + 1);
                    Set<String> setA = new HashSet<>();

                    // Add all values of columnA to setA
                    for (List<String> row : tableA) {
                        setA.add(row.get(columnA).trim().toLowerCase());  // Normalize case and trim
                    }

                    // Compare with every column in tableB
                    for (int columnB = 0; columnB < tableB.get(0).size(); columnB++) {
                        String columnBName = "Table " + (j + 1) + " Column " + (columnB + 1);

                        // Check if all values in columnB are in setA
                        for (List<String> row : tableB) {
                            String item = row.get(columnB).trim().toLowerCase();  // Normalize case and trim
                            if (!setA.contains(item)) {
                                System.out.println("No Inclusion Dependency between " + columnAName + " and " + columnBName + ": " + item);
//                                isValid = false;  // If any item in tableB is not in setA, mark as invalid
                            } else {
                                isValid = true;
                                System.out.println("Inclusion Dependency between " + columnAName + " and " + columnBName + ": " + item);
                            }
                        }
                    }
                }
            }
        }

        return isValid;  // Return whether all inclusion dependencies are satisfied
    }

}
