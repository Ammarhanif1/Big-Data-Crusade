package de.ddm.example;

import akka.actor.AbstractActor;

public class DependencyMiner extends AbstractActor {

    private int validCount = 0;
    private int totalWorkers = 1; // Adjust the number of workers as needed
    private boolean dependencyValid = true;

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(WorkerResult.class, result -> {
                    if (!result.isDependencyValid) {
                        // If any worker returns false, set the dependency to false
                        dependencyValid = false;
                        System.out.println("Inclusion Dependency Check Failed: " + result.comparisonInfo);
                    }

                    validCount++;

                    if (validCount == totalWorkers) {
                        // If all workers have responded, finalize and print the result
                        System.out.println("Inclusion Dependency Valid: " + dependencyValid);

                        // Send FinalizeMessage to mark the end of time measurement
                        getContext().getSystem().actorSelection("/user/resultCollector").tell(new FinalizeMessage(), getSelf());

                        // Shut down the system
                        getContext().getSystem().terminate();
                    }
                })
                .build();
    }
}
