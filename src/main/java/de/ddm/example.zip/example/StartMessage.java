package de.ddm.example;
public class StartMessage {
    // This class will be used to signal the start of the time measurement.
}
