package de.ddm.example;
import java.util.List;

public class CheckData {
    public final List<List<List<String>>> allTables; // A list of all tables (each table is a list of rows)

    public CheckData(List<List<List<String>>> allTables) {
        this.allTables = allTables;
    }
}
