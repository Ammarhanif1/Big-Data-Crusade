package de.ddm.example;

import akka.actor.AbstractActor;

public class ResultCollector extends AbstractActor {

    @Override
    public Receive createReceive() {
        return receiveBuilder()
                .match(StartMessage.class, msg -> {
                    // Start timing
                    System.out.println("Starting the Inclusion Dependency discovery process...");
                })
                .match(FinalizeMessage.class, msg -> {
                    // End timing and print final result
                    System.out.println("Inclusion Dependency discovery process completed.");
                    getContext().getSystem().terminate();
                })
                .build();
    }
}
